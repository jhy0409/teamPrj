﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace teamProject
{
    public partial class DrugCompInfo_Form : Form
    {
        public DrugCompInfo_Form()
        {
            InitializeComponent();
        }

    }
}
